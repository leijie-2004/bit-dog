import numpy as np
from scipy.optimize import least_squares
import math
import logging
from . import dog_imformation as di
# 配置 logger
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def angle_to_xyz(b0,b1,b2,a1):#按顺序输入三个关节的角度，和Iabcd，左右腿不一样，得到足末端相对于大腿根部xyz坐标
    x=di.l2*np.sin(b1+b2)+di.l1*np.sin(b1)
    y=-di.l2*np.sin(b0)*np.cos(b1+b2)+a1*np.cos(b0)-di.l2*np.cos(b1)*np.sin(b0)
    z=di.l2*np.cos(b0)*np.cos(b1+b2)+a1*np.sin(b0)+di.l1*np.cos(b0)*np.cos(b1)
    return x,y,z

def inverse_angle_back(x, y, z, a1, l1, l2):#输入足末端相对于大腿根部的xyz位置，Iabcd，Ihip，Iknee，逆运动学结算反馈各个电机角度
    
    L = np.sqrt(y**2+z**2-a1**2)
    b0=np.arctan2(z*a1+y*L,y*a1-z*L)
    b2=-np.pi+np.arccos((l2**2+l1**2-(x**2+y**2+z**2-a1**2))/2/l1/l2)
    a0=y*np.sin(b0)-z*np.cos(b0)
    a2=x
    m1=l2*np.sin(b2)
    m2=l2*np.cos(b2)+l1
    b1=np.arctan2(a0*m1+a2*m2,a2*m1-a0*m2)
    
    return b0,b1,b2
def restrict_in_pi(num):
    if(num>np.pi):
        num=num-2*np.pi
    elif(num<-np.pi):
        num=num+2*np.pi
    return num
def interpolate_points_3d(start_point, end_point, max_distance):
    """
    在三维空间的起点和终点之间插值，确保每两个点之间的最大距离不超过 max_distance。
    
    :param start_point: tuple, 起点坐标 (x1, y1, z1)
    :param end_point: tuple, 终点坐标 (x2, y2, z2)
    :param max_distance: float, 每两个点之间的最大距离
    
    :return: list of tuples, 插值后的点的列表
    """
    # 计算起点和终点之间的三维空间直线距离
    distance = math.sqrt((end_point[0] - start_point[0]) ** 2 + 
                         (end_point[1] - start_point[1]) ** 2 + 
                         (end_point[2] - start_point[2]) ** 2)
    
    # 如果起点和终点之间的距离小于或等于最大距离，直接返回起点和终点
    if distance <= max_distance:
        return [start_point, end_point]

    # 计算步长（步进方向）
    num_steps = math.ceil(distance / max_distance)  # 计算插值步数
    step_x = (end_point[0] - start_point[0]) / num_steps
    step_y = (end_point[1] - start_point[1]) / num_steps
    step_z = (end_point[2] - start_point[2]) / num_steps

    # 生成插值点
    points = []
    for i in range(num_steps + 1):
        x = start_point[0] + i * step_x
        y = start_point[1] + i * step_y
        z = start_point[2] + i * step_z
        points.append((x, y, z))

    return points


def generate_Jacobi(b0, b1, b2, a1,regularization_factor=0):#输入三个关节角度和Iabcd输出雅可比矩阵
    # 创建雅可比矩阵 J
    J = np.array([
        [0,
         di.l2*np.cos(b1+b2)+di.l1*np.cos(b1),
         di.l2*np.cos(b1+b2)],
        
        [-a1*np.sin(b0)-di.l1*np.cos(b0)*np.cos(b1)-di.l2*np.cos(b0)*np.cos(b1+b2),
         di.l1*np.sin(b0)*np.sin(b1)+di.l2*np.sin(b0)*np.sin(b1+b2),
         di.l2*np.sin(b0)*np.sin(b1+b2)],

        [a1*np.cos(b0)-di.l1*np.sin(b0)*np.cos(b1)-di.l2*np.sin(b0)*np.cos(b1+b2),
         -di.l1*np.cos(b0)*np.sin(b1)-di.l2*np.cos(b0)*np.sin(b1+b2),
         -di.l2*np.cos(b0)*np.sin(b1+b2)
        ]
    ])
    # 添加正则化因子到对角线
    # regularized_J = J + regularization_factor * np.eye(J.shape[0])
    return J 


def compute_end_effector_velocity(b0, b1, b2,a1, b0_dot, b1_dot, b2_dot):#输入三个关节的角度，Iabcd，和三个关节的速度算出足末端相对于每个足原点的位置
    # 计算 a2
    # 计算雅可比矩阵
    J = generate_Jacobi(b0,b1,b2,a1)
    # 计算末端速度
    joint_velocities = np.array([b0_dot, b1_dot, b2_dot])
    xyz_velocity = J @ joint_velocities

    return xyz_velocity

def xyz_power_to_tor(x_F,y_F,z_F, b0, b1, b2,a1):#输入足末端虚拟力，三个关节角度，和Iabcd，输出每个关节力矩
    F=np.asarray([x_F,y_F,z_F])
    J = generate_Jacobi(b0,b1,b2,a1)
    Jt=J.T
    TOR = np.dot(Jt, F)
    return TOR.tolist()


def calculate_jacobian(a1, l1, l2, b0, b1, b2):
    return np.array([
    [0,
    l2 * np.cos(b1 + b2) + l1 * np.cos(b1),
    l2 * np.cos(b1 + b2)],

    [-a1 * np.sin(b0) - l1 * np.cos(b0) * np.cos(b1) - l2 * np.cos(b0) * np.cos(b1 + b2),
    l1 * np.sin(b0) * np.sin(b1) + l2 * np.sin(b0) * np.sin(b1 + b2),
    l2 * np.sin(b0) * np.sin(b1 + b2)],

    [a1 * np.cos(b0) - l1 * np.sin(b0) * np.cos(b1) - l2 * np.sin(b0) * np.cos(b1 + b2),
    -l1 * np.cos(b0) * np.sin(b1) - l2 * np.cos(b0) * np.sin(b1 + b2),
    -l2 * np.cos(b0) * np.sin(b1 + b2)
    ]
    ])


def tor_to_xyz_power(torx,tory,torz, b0, b1, b2,a1):#输入每个关节角度，三个关节角度，和Iabcd，输出足末端虚拟力
    J_T=np.zeros((3,3))
    J_T_inv=np.zeros((3,3))
    J=np.zeros((3,3))
    TOR = np.asarray([torx,tory,torz]).reshape(-1, 1)  # 转换为列向量
    J = generate_Jacobi(b0,b1,b2,a1)
    J_T=J.T
    try:
        J_T_inv=np.linalg.pinv(J_T)
        flag=1
    except np.linalg.LinAlgError:
        print("not")
        flag=0
    
    # 转换为列矩阵 # 计算雅可比矩阵与 tau 的乘积 
    if flag==1:
        # print(J_T_inv)
        # print(TOR)
        F = np.dot(J_T_inv, TOR).flatten()
        # print(leg_rb.q)
        # print(tau_vector)
        # # print(J_T_inv)
        # print(F)
        return F
    else:
        print("error")
    