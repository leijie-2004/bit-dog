import rclpy
from rclpy.node import Node
import logging
import time
import json
import os
from . import dog_leg_inverse2
from . import dog_imformation as di
from . import motor as m
from std_msgs.msg import Float64
from sensor_msgs.msg import JointState
from . import gait_plan as g
from sensor_msgs.msg import Imu
import numpy as np
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
class StatecontrolNode(Node):
    def __init__(self):
        super.__init__("state_control")
        topic_prefix= "robot/"
        