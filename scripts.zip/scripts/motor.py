
import time
import sys
import numpy as np
sys.path.append('/home/rm/download/fish_ws_gou8/fish_ws/fishbot_description/fishbot_description/lib')
from unitree_actuator_sdk import *
import logging
from . import dog_imformation as di
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
from . import dog_leg_inverse2



class imu:
    Orientation=[0,0,0,0]
    Angular_Velocity=[0,0,0]
    Linear_Acceleration=[0,0,0]

class leg:
    def __init__(self, USB, offset0, offset1, offset2):#电机反馈信息
        self.USB = USB
        self.offset = [offset0, offset1, offset2]
        self.q_last=[0,0,0]
        self.q = [0, 0, -3.14/2]
        self.dq = [0, 0, 0]
        self.tau = [0, 0, 0] # 扭矩矩阵

class foot_calculate_information:#足末端信息
    def __init__(self,name1):
        self.name=name1
        self.toe_power=[0,0,0]#力
        self.prev_toe_power=[0,0,0]#历史力
        self.toe_position_feedback=[0,0,0]#位置相对于机器人中心
        self.toe_position_feedback_raw=[0,0,0]#相对于机器人腿根部
        self.toe_position_feedback_raw_planed=[0,0,0]
        self.toe_velocity_callback=[0,0,0]#速度
        self.prev_toe_velocity_callback = [0, 0, 0]  # 历史速度

class body_h:#身体高度期望与反馈
    def __init__(self):
        self.int=0#期望
        self.out=0#反馈

class foot_expected_information:#期望的足末端信息
    def __init__(self,name1):
        self.name=name1
        self.toe_power=[0,0,0]#力
        self.toe_position_feedback=[0,0,0]#相对中心位置
        self.toe_velocity_callback=[0,0,0]#速度

class motors_information:#输入的电机信息
    def __init__(self):
        self.q=[0,0,0]
        self.dq=[0,0,0]
        self.tau=[0,0,0]

def calculate_foot_information(foot_calculate_information_here,q,dq,tau):#把相应信息输入到foot_calculate_information类里面
    
    if foot_calculate_information_here.name=="rb":#检测这是哪条腿
        #正运动学结算，相对于根部坐标
        x,y,z=dog_leg_inverse2.angle_to_xyz( q[0],q[1],q[2],-di.a1)
        #相对于中心点坐标
        foot_calculate_information_here.toe_position_feedback=[x,y,z]+di.vector_rb
        foot_calculate_information_here.toe_position_feedback_raw=[x,y,z]
        #雅各比矩阵计算足力矩
        foot_calculate_information_here.toe_power=np.array(dog_leg_inverse2.tor_to_xyz_power(tau[0],tau[1],tau[2], q[0],q[1],q[2],-di.a1))
        #雅各比矩阵计算足速度
        foot_calculate_information_here.toe_velocity_callback=np.array(dog_leg_inverse2.compute_end_effector_velocity(q[0],q[1],q[2],-di.a1,dq[0],dq[1],dq[2]))
    elif foot_calculate_information_here.name=="lf":
        x,y,z=dog_leg_inverse2.angle_to_xyz( q[0],q[1],q[2],di.a1)
        foot_calculate_information_here.toe_position_feedback=[x,y,z]+di.vector_lf
        foot_calculate_information_here.toe_position_feedback_raw=[x,y,z]
        foot_calculate_information_here.toe_power=np.array(dog_leg_inverse2.tor_to_xyz_power(tau[0],tau[1],tau[2], q[0],q[1],q[2],di.a1))
        foot_calculate_information_here.toe_velocity_callback=np.array(dog_leg_inverse2.compute_end_effector_velocity(q[0],q[1],q[2],di.a1,dq[0],dq[1],dq[2]))
    elif foot_calculate_information_here.name=="rf":
        x,y,z=dog_leg_inverse2.angle_to_xyz( q[0],q[1],q[2],-di.a1)
        foot_calculate_information_here.toe_position_feedback=[x,y,z]+di.vector_rf
        foot_calculate_information_here.toe_position_feedback_raw=[x,y,z]
        foot_calculate_information_here.toe_power=np.array(dog_leg_inverse2.tor_to_xyz_power(tau[0],tau[1],tau[2], q[0],q[1],q[2],-di.a1))
        foot_calculate_information_here.toe_velocity_callback=np.array(dog_leg_inverse2.compute_end_effector_velocity(q[0],q[1],q[2],-di.a1,dq[0],dq[1],dq[2]))
    elif foot_calculate_information_here.name=="lb":
        x,y,z=dog_leg_inverse2.angle_to_xyz( q[0],q[1],q[2],di.a1)
        foot_calculate_information_here.toe_position_feedback_raw=[x,y,z]
        foot_calculate_information_here.toe_position_feedback=[x,y,z]+di.vector_lb
        foot_calculate_information_here.toe_power=np.array(dog_leg_inverse2.tor_to_xyz_power(tau[0],tau[1],tau[2], q[0],q[1],q[2],di.a1))
        foot_calculate_information_here.toe_velocity_callback=np.array(dog_leg_inverse2.compute_end_effector_velocity(q[0],q[1],q[2],di.a1,dq[0],dq[1],dq[2]))

#类的声明    
leg_rb = leg('/dev/ttyUSB1',0,-3.14/3+3.14/2,-3.14/5-3.14/2)
leg_lb = leg('/dev/ttyUSB2',0,-3.14/6+3.14/2,-3.14/5-3.14/2)
leg_rf = leg('/dev/ttyUSB1',0.44,0.4,-1-3.14/2)
leg_lf = leg('/dev/ttyUSB2',-0.14,-0.2,1.12-3.14/2)
information_rb=foot_calculate_information("rb")

information_rf=foot_calculate_information("rf")

information_lb=foot_calculate_information("lb")

information_lf=foot_calculate_information("lf")

motor_rb_ex=motors_information()
motor_lb_ex=motors_information()
motor_lf_ex=motors_information()
motor_rf_ex=motors_information()
# motor_rb_fd=motors_information()
# motor_lb_fd=motors_information()
# motor_lf_fd=motors_information()
# motor_rf_fd=motors_information()





