import numpy as np
a1=0.101#Iabcd
l1=-0.21#Ihip
l2=-0.231#Iknee
vector_lf=np.asarray([0.225,0.063,0])#左前腿机器人质心指向腿坐标原点的矢量
vector_rf=np.asarray([0.225,-0.063,0])#右前腿机器人质心指向腿坐标原点的矢量
vector_lb=np.asarray([-0.225,0.063,0])#左后腿机器人质心指向腿坐标原点的矢量
vector_rb=np.asarray([-0.225,-0.063,0])#右后腿机器人质心指向腿坐标原点的矢量