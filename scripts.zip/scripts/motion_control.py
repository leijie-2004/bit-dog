import numpy as np
from . import dog_imformation as di
from . import dog_leg_inverse2
import logging
import cvxpy as cp 
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
def plan_power(px,py,pz,px_dot,py_dot,pz_dot,K,D,exp,exp_dot):#输入机器人质心位置，速度，K和D参数，期望的位置，期望的速度，输出机器人质心上应该有的平动虚拟力
    Fx=K*(exp[0]-px)+D*(exp_dot[0]-px_dot)
    Fy=K*(exp[1]-py)+D*(exp_dot[1]-py_dot)
    Fz=K*(exp[2]-pz)+D*(exp_dot[2]-pz_dot)
    return Fx,Fy,Fz

# def leg_power_to_body_power_inverse(vector_lf, vector_rf, vector_lb, vector_rb, power_body, tor_body, is_foot_touch_ground):
#     """
#     已知四足支撑点位置 (vector_xx) 和 机器人整体受力/力矩 (power_body, tor_body)，
#     计算各个支撑腿的作用力 (power_lf, power_rf, power_lb, power_rb).
   
#     参数:
#     - vector_lf, vector_rf, vector_lb, vector_rb: 每条腿的支撑点相对于重心的坐标 (1x3 numpy 数组)
#     - power_body: 机器人受到的总合力 (1x3 numpy 数组)
#     - tor_body: 机器人受到的总力矩 (1x3 numpy 数组)
   
#     返回:
#     - power_lf, power_rf, power_lb, power_rb: 各腿的受力 (1x3 numpy 数组)
#     """


#     A = np.vstack([
#         np.hstack([np.eye(3), np.eye(3)]),  # 力的总和
#         np.hstack([
#             np.cross(vector_lf, np.eye(3), axis=0),
#             np.cross(vector_lb, np.eye(3), axis=0),
#         ])  # 力矩约束
#     ])  # 6x6 矩阵
    
#     # 构建右侧矩阵 b (6x1)
#     b = np.hstack([power_body, tor_body])  # 1x6
#     f1=np.linalg.lstsq(A, b, rcond=None)[0]

#     A = np.vstack([
#         np.hstack([np.eye(3), np.eye(3)]),  # 力的总和
#         np.hstack([
#             np.cross(vector_rf, np.eye(3), axis=0),
#             np.cross(vector_rb, np.eye(3), axis=0),
#         ])  # 力矩约束
#     ])  # 6x6 矩阵

#     f2=np.linalg.lstsq(A, b, rcond=None)[0]
#     logger.info(f"Rf1{f1}")
#     logger.info(f"Rf2{f2}")
#     return f1[0:3], f2[0:3], f1[3:6], f2[3:6]



def leg_power_to_body_power_inverse(vector_lf, vector_rf, vector_lb, vector_rb, power_body, tor_body, is_foot_touch_ground):
    """
    已知四足支撑点位置 (vector_xx) 和 机器人整体受力/力矩 (power_body, tor_body)，
    计算各个支撑腿的作用力 (power_lf, power_rf, power_lb, power_rb).
   
    参数:
    - vector_lf, vector_rf, vector_lb, vector_rb: 每条腿的支撑点相对于重心的坐标 (1x3 numpy 数组)
    - power_body: 机器人受到的总合力 (1x3 numpy 数组)
    - tor_body: 机器人受到的总力矩 (1x3 numpy 数组)
   
    返回:
    - power_lf, power_rf, power_lb, power_rb: 各腿的受力 (1x3 numpy 数组)
    """
    # 构建系数矩阵 A (6x12)
    mu=0.5
    A = np.vstack([
        np.hstack([np.eye(3), np.eye(3), np.eye(3), np.eye(3)]),  # 力的总和
        np.hstack([
            np.cross(vector_lf, np.eye(3), axis=0),
            np.cross(vector_rf, np.eye(3), axis=0),
            np.cross(vector_lb, np.eye(3), axis=0),
            np.cross(vector_rb, np.eye(3), axis=0),
        ])  # 力矩约束
    ])  # 6x12 矩阵
    b = np.hstack([power_body, tor_body])  # 1x6
    b_T=b.T
    # logger.info(f"Rb_T{b_T}")
    # 二次规划部分
    f = cp.Variable(12)
    objective = cp.Minimize(cp.sum_squares(f))#最小约束
    constraints = [A @ f == b_T] #力矩平衡和力平衡约束
    # 修改目标函数：最小化 x 和 y 方向的力
    objective = cp.Minimize(f[0]**2 + f[1]**2 + f[3]**2 + f[4]**2 + f[6]**2 + f[7]**2 + f[9]**2 + f[10]**2)  # 最小化各腿 x, y 方向的力平方和

    # 力矩平衡和力平衡约束
    constraints = [A @ f == b]

    # # 添加足部触地的约束
    if is_foot_touch_ground[0] == 0:
        constraints.append(f[0] == 0)
        constraints.append(f[1] == 0)
        constraints.append(f[2] == 0)
    else:
        constraints.append(f[2] >= 0)  # 如果触地，f[2] 应该为负值

    if is_foot_touch_ground[1] == 0:
        constraints.append(f[3] == 0)
        constraints.append(f[4] == 0)
        constraints.append(f[5] == 0)
    else:
        constraints.append(f[5] >= 0)  # 如果触地，f[5] 应该为负值

    if is_foot_touch_ground[2] == 0:
        constraints.append(f[6] == 0)
        constraints.append(f[7] == 0)
        constraints.append(f[8] == 0)
    else:
        constraints.append(f[8] >= 0)  # 如果触地，f[8] 应该为负值

    if is_foot_touch_ground[3] == 0:
        constraints.append(f[9] == 0)
        constraints.append(f[10] == 0)
        constraints.append(f[11] == 0)
    else:
        constraints.append(f[11] >= 0)  # 如果触地，f[11] 应该为负值

    if is_foot_touch_ground[0] == 1:  # 前左腿
        constraints.append(cp.abs(f[0]) <= mu * f[2])  # x 方向的力小于摩擦力
        constraints.append(cp.abs(f[1]) <= mu * f[2])  # y 方向的力小于摩擦力
    if is_foot_touch_ground[1] == 1:  # 前右腿
        constraints.append(cp.abs(f[3]) <= mu * f[5])  # x 方向的力小于摩擦力
        constraints.append(cp.abs(f[4]) <= mu * f[5])  # y 方向的力小于摩擦力
    if is_foot_touch_ground[2] == 1:  # 后左腿
        constraints.append(cp.abs(f[6]) <= mu * f[8])  # x 方向的力小于摩擦力
        constraints.append(cp.abs(f[7]) <= mu * f[8])  # y 方向的力小于摩擦力
    if is_foot_touch_ground[3] == 1:  # 后右腿
        constraints.append(cp.abs(f[9]) <= mu * f[11])  # x 方向的力小于摩擦力
        constraints.append(cp.abs(f[10]) <= mu * f[11])  # y 方向的力小于摩擦力
        # 求解问题

    prob = cp.Problem(objective, constraints)
    prob.solve(solver=cp.OSQP)

        # 确保求解成功
    if f.value is None:
            raise RuntimeError("QP求解失败")
            return 0,0,0,0
            
            
    else:
            return f.value[0:3], f.value[3:6], f.value[6:9], f.value[9:12]
   
   
def leg_power_to_body_power(vector_lf,vector_rf,vector_lb,vector_rb,power_lf,power_rf,power_lb,power_rb):#输入四条腿机器人质心指向每个腿坐标原点的矢量，每个腿上的虚拟力得到机器人质心上的力和力矩
    power_body=power_lf+power_rf+power_lb+power_rb
    tor_body=np.cross(vector_lf,power_lf)+np.cross(vector_rf,power_rf)+np.cross(vector_lb,power_lb)+np.cross(vector_rb,power_rb)
    return power_body,tor_body

def plan_legs_power(px, py, pz, 
                    px_dot, py_dot, pz_dot, 
                    K, D, 
                    exp, exp_dot,
                    pwx, pwy, pwz, 
                    pwx_dot, pwy_dot, pwz_dot,
                    Kw, Dw,
                    expw, expw_dot,is_foot_touch_ground,
                    b_lf, b_rf, b_lb, b_rb):
    """Calculate leg forces with numeric validation"""
    
    def is_numeric(value):
        """Check if value is numeric (int or float) or numpy numeric"""
        return isinstance(value, (int, float, np.number))
    
    def all_elements_numeric(arr):
        """Check all elements in an array are numeric"""
        return all(is_numeric(x) for x in np.asarray(arr).flatten())
    
    # Calculate desired body forces
    Fx, Fy, Fz = plan_power(px, py, pz, px_dot, py_dot, pz_dot, K, D, exp, exp_dot)
    Tx, Ty, Tz = plan_power(pwx, pwy, pwz, pwx_dot, pwy_dot, pwz_dot, Kw, Dw, expw, expw_dot)
    # logger.info(f"F: {Fx, Fy, Fz}")
    # logger.info(f"T: {Tx, Ty, Tz}")
    # Calculate leg positions
    x_lf, y_lf, z_lf = dog_leg_inverse2.angle_to_xyz(b_lf[0], b_lf[1], b_lf[2], di.a1)
    x_rf, y_rf, z_rf = dog_leg_inverse2.angle_to_xyz(b_rf[0], b_rf[1], b_rf[2], -di.a1)
    x_lb, y_lb, z_lb = dog_leg_inverse2.angle_to_xyz(b_lb[0], b_lb[1], b_lb[2], di.a1)
    x_rb, y_rb, z_rb = dog_leg_inverse2.angle_to_xyz(b_rb[0], b_rb[1], b_rb[2], -di.a1)

    # Calculate vectors from COM to feet
    v1 = np.asarray([x_lf, y_lf, z_lf]) + di.vector_lf
    v2 = np.asarray([x_rf, y_rf, z_rf]) + di.vector_rf
    v3 = np.asarray([x_lb, y_lb, z_lb]) + di.vector_lb
    v4 = np.asarray([x_rb, y_rb, z_rb]) + di.vector_rb
    # logger.info(f"原始足位置: {v1,v2,v3,v4}m")
    v1=v1.reshape(-1, 1)#3*1矩阵
    v2=v2.reshape(-1, 1)
    v3=v3.reshape(-1, 1)
    v4=v4.reshape(-1, 1)
    # Prepare force and torque arrays
    F = np.asarray([Fx, Fy, Fz])
    T = np.asarray([Tx, Ty, Tz])
    
    # Validate all inputs are numeric before calculation
    all_valid = (all_elements_numeric(v1) and 
                all_elements_numeric(v2) and 
                all_elements_numeric(v3) and 
                all_elements_numeric(v4) and 
                all_elements_numeric(F) and 
                all_elements_numeric(T))
    
    if not all_valid:
        print("Warning: Non-numeric values detected in inputs!")
        print(f"v1: {v1}, v2: {v2}, v3: {v3}, v4: {v4}")
        print(f"F: {F}, T: {T}")
        return np.zeros(3), np.zeros(3), np.zeros(3), np.zeros(3)
    
    # Only proceed if all inputs are numeric
    try:
        power_lf, power_rf, power_lb, power_rb = leg_power_to_body_power_inverse(
            v1, v2, v3, v4, F, T,is_foot_touch_ground)
        power_lf=[-x for x in power_lf]
        power_rf=[-x for x in power_rf]
        power_lb=[-x for x in power_lb]
        power_rb=[-x for x in power_rb]
        return power_lf, power_rf, power_lb, power_rb
    except Exception as e:
        print(f"Error in leg_power_to_body_power_inverse: {e}")
        return np.zeros(3), np.zeros(3), np.zeros(3), np.zeros(3)


def plan_position(lj,roll,pitch,yaw,klf,krf,klb,krb,l1,l2,vx,vy,t):
    position = [0] * 12
    #z轴
    position[2]=position[2]+klf*l1*pitch-klf*l2*roll
    position[5]=position[5]+krf*l1*pitch+krf*l2*roll
    position[8]=position[8]-klb*l1*pitch-klb*l2*roll
    position[11]=position[11]-krb*l1*pitch+krb*l2*roll
    #x轴
    position[0]=position[0]-vx*t
    position[3]=position[3]-vx*t
    position[6]=position[6]-vx*t
    position[9]=position[9]-vx*t
    #y轴
    position[2]=position[2]-vy*t
    position[5]=position[5]-vy*t
    position[8]=position[8]-vy*t
    position[11]=position[11]-vy*t
    return tuple(position)
# def plan_leg_power2(px, py, pz,px_dot, py_dot, pz_dot,K, D, exp, exp_dot,pwx, pwy, pwz, pwx_dot, pwy_dot, pwz_dot,Kw, Dw,expw, expw_dot, vector_lf, vector_rf, vector_lb, vector_rb):
#     Fx, Fy, Fz = plan_power(px, py, pz, px_dot, py_dot, pz_dot, K, D, exp, exp_dot)
#     Tx, Ty, Tz = plan_power(pwx, pwy, pwz, pwx_dot, pwy_dot, pwz_dot, Kw, Dw, expw, expw_dot)
#     logger.info(f"F: {Fx, Fy, Fz}")
#     logger.info(f"T: {Tx, Ty, Tz}")
#     F = np.asarray([Fx, Fy, Fz])
#     T = np.asarray([Tx, Ty, Tz])
#     def is_numeric(value):
#         """Check if value is numeric (int or float) or numpy numeric"""
#         return isinstance(value, (int, float, np.number))
    
#     def all_elements_numeric(arr):
#         """Check all elements in an array are numeric"""
#         return all(is_numeric(x) for x in np.asarray(arr).flatten())
#     all_valid = (all_elements_numeric(vector_lf) and 
#                 all_elements_numeric(vector_rf) and 
#                 all_elements_numeric(vector_lb) and 
#                 all_elements_numeric(vector_rb) and 
#                 all_elements_numeric(F) and 
#                 all_elements_numeric(T))
#     if not all_valid:
#         print("Warning: Non-numeric values detected in inputs!")

#         print(f"F: {F}, T: {T}")
#         return np.zeros(3), np.zeros(3), np.zeros(3), np.zeros(3)
#     try:
#         power_lf, power_rf, power_lb, power_rb=inverse_power_back([Fx,Fy,Fz], [Tx,Ty,Tz], vector_lf, vector_rf, vector_lb, vector_rb)
#         return power_lf, power_rf, power_lb, power_rb
#     except Exception as e:
#         print(f"Error in leg_power_to_body_power_inverse: {e}")
#         return np.zeros(3), np.zeros(3), np.zeros(3), np.zeros(3)


# def inverse_power_back(F, T, vector_lf, vector_rf, vector_lb, vector_rb):
#     # 构建矩阵 A
#     A = np.array([
#         [1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0],
#         [0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0],
#         [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1],
#         [0, 0, 0, 0, vector_lf[2], vector_rf[2], vector_lb[2], vector_rb[2], -vector_lf[1], -vector_rf[1], -vector_lb[1], -vector_rb[1]],
#         [-vector_lf[2], -vector_rf[2], -vector_lb[2], -vector_rb[2], 0, 0, 0, 0, vector_lf[0], vector_rf[0], vector_lb[0], vector_rb[0]],
#         [vector_lf[0], vector_rf[0], vector_lb[0], vector_rb[0], vector_lf[1], vector_rf[1], vector_lb[1], vector_rb[1], 0, 0, 0, 0]
#     ])
    
#     # 构建向量 B
#     B = np.array([F[0], F[1], F[2], T[0], T[1], T[2]])

#     # 使用最小二乘法求解
#     x, resids, rank, s = np.linalg.lstsq(A, B, rcond=None)

#     # 分解解 x 成不同的功率
#     power_lf =np.asarray( [-x[0], -x[4], -x[8]])
#     power_rf =np.asarray( [-x[1], -x[5], -x[9]])
#     power_lb =np.asarray( [-x[2], -x[6], -x[10]])
#     power_rb =np.asarray( [-x[3], -x[7], -x[11]])

#     return power_lf, power_rf, power_lb, power_rb