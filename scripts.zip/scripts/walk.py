import rclpy
from rclpy.node import Node
import logging
import time
import json
import os
from . import dog_leg_inverse2
from . import dog_imformation as di
from . import motor as m
from std_msgs.msg import Float64
from sensor_msgs.msg import JointState
from std_msgs.msg import Float64MultiArray
from . import gait_plan as g
from sensor_msgs.msg import Imu
import numpy as np
from . import motion_control as mc
import threading
FORCE_THRESHOLD = 0.2 # 速度突变阈值
#  from g import sp_rb, sp_lb, sp_rf, sp_lf

# 配置 logger
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DogLegControlNode(Node):

    def __init__(self):
        super().__init__('walk')
        # self.l1=0
        topic_prefix= "robot/"
        # 为每个关节创建单独的发布者，整个节点工作空间都放到了robot
        self.my_publishers = {
            'lf': self.create_publisher(JointState, topic_prefix+'lf', 30),
            'rf': self.create_publisher(JointState, topic_prefix+'rf', 30),
            'lb': self.create_publisher(JointState, topic_prefix+'lb', 30),
            'rb': self.create_publisher(JointState, topic_prefix+'rb', 30),
            'lf_para': self.create_publisher(Float64MultiArray, topic_prefix+'lf_para', 30),
            'rf_para': self.create_publisher(Float64MultiArray, topic_prefix+'rf_para', 30),
            'lb_para': self.create_publisher(Float64MultiArray, topic_prefix+'lb_para', 30),
            'rb_para': self.create_publisher(Float64MultiArray, topic_prefix+'rb_para', 30),
        }
        self.my_subscriptions = {
            'lf_feedback': self.create_subscription(JointState,  topic_prefix+'lf_feedback', self.lfw_callback, 30),
            'rf_feedback': self.create_subscription(JointState,  topic_prefix+'rf_feedback', self.rfw_callback, 30),
            'lb_feedback': self.create_subscription(JointState,  topic_prefix+'lb_feedback', self.lbw_callback, 30),
            'rb_feedback': self.create_subscription(JointState,  topic_prefix+'rb_feedback', self.rbw_callback, 30),
        }
        self.subscription = self.create_subscription(
            Imu,
            '/imu',
            self.imu_callback,
            10  # 队列大小
        )
        self.lf_end_flag=0#每个腿走到最后还没触地flag
        self.rf_end_flag=0
        self.lb_end_flag=0
        self.rb_end_flag=0
        self.lf_stand_flag=0#每个腿触地flag
        self.rf_stand_flag=0
        self.lb_stand_flag=0
        self.rb_stand_flag=0
        self.lf_stand_flag1=0#第一次改变状态flag。0为1变0,1为0变1
        self.rf_stand_flag1=0
        self.lb_stand_flag1=0
        self.rb_stand_flag1=0
        self.lf_mode=0
        self.rf_mode=0
        self.rb_mode=0
        self.lb_mode=0
        self.time_mode_change=1
        self.body_velocity=[0.0 , 0.0 ,0.0]
        self.each_point_timer_period = 0.0001
        self.timer_walk_rb = self.create_timer(self.each_point_timer_period, self.timer_walk_callback_rb)#定时器中断
        self.timer_walk_lb = self.create_timer(self.each_point_timer_period, self.timer_walk_callback_lb)#定时器中断
        self.timer_walk_rf = self.create_timer(self.each_point_timer_period, self.timer_walk_callback_rf)#定时器中断
        self.timer_walk_lf = self.create_timer(self.each_point_timer_period, self.timer_walk_callback_lf)#定时器中断
        self.timer_mode_change=self.create_timer(self.time_mode_change,self.mode_change_callback)
        self.power_lf=[0  , 0 ,0]
        self.power_rf=[0  , 0 ,0]
        self.power_lb=[0  , 0 ,0]
        self.power_rb=[0  , 0 ,0]
        self.stand_mode=0#0为左前右后支撑，1为右前左后支撑
        # 新增身体信息相关变量
        self.body = [0,0,0]
        self.euler_angles = (0.0, 0.0, 0.0)  # (roll, pitch, yaw)

                # 创建并启动控制线程
        self._thread_running = True
        self.control_thread = threading.Thread(target=self._leg_control_loop)
        self.control_thread.start()
        
        # 确保节点销毁时线程退出





                
    def _leg_control_loop(self):

        
        while self._thread_running:
            if(self.stand_mode==0):#stand_mode  0为左前右后支撑，1为右前左后支撑
                self.lf_mode=1#状态转换
                self.rb_mode=1
                self.rf_mode=0
                self.lb_mode=0
                if self.rf_end_flag==1 and self.lb_end_flag==1:#end代表一个gait_plan周期已经走到末尾
                    logger.info("0 change to stand mode 1")
                    self.stand_mode=1
                    self.rf_stand_flag=0
                    self.lb_stand_flag=0
                    self.rb_stand_flag=0
                    self.lf_stand_flag=0
                    self.rf_end_flag=0
                    self.lb_end_flag=0
                elif self.rf_stand_flag==1 and self.lb_stand_flag==1:#stand表示足末端触地了
                    logger.info("change to stand mode 1,touch success")
                    self.stand_mode=1
                    self.rf_stand_flag=0
                    self.lb_stand_flag=0
                    self.rb_stand_flag=0
                    self.lf_stand_flag=0
                    self.rf_end_flag=0
                    self.lb_end_flag=0
            elif (self.stand_mode==1):
                self.lf_mode=0
                self.rb_mode=0
                self.rf_mode=1
                self.lb_mode=1
                if self.lf_end_flag==1 and self.rb_end_flag==1:
                    logger.info("1 change to stand mode 0")
                    self.stand_mode=0
                    self.rf_stand_flag=0
                    self.lb_stand_flag=0
                    self.rb_stand_flag=0
                    self.lf_stand_flag=0
                    self.lf_end_flag=0
                    self.rb_end_flag=0
                elif self.lf_stand_flag==1 and self.rb_stand_flag==1:
                    logger.info("change to stand mode 0,touch change")
                    self.stand_mode=0
                    self.rf_stand_flag=0
                    self.lb_stand_flag=0
                    self.rb_stand_flag=0
                    self.lf_stand_flag=0
                    self.lf_end_flag=0
                    self.rb_end_flag=0
    def destroy_node(self):
        """重写销毁方法确保线程退出"""
        self._thread_running = False
        if hasattr(self, 'control_thread') and self.control_thread.is_alive():
            self.control_thread.join(timeout=1.0)
        super().destroy_node()       
    def imu_callback(self, msg):
        """处理IMU数据并转换欧拉角"""
        # 存储原始IMU数据

        
        # 手动转换四元数到欧拉角
        try:
            q = [
                msg.orientation.x,
                msg.orientation.y,
                msg.orientation.z,
                msg.orientation.w
            ]
            self.euler_angles = self._quat_to_euler(q)
            # self.euler_angles[0]=self.euler_angles[0]-3.14
        except Exception as e:
            logger.error(f"四元数转换失败: {str(e)}")
            self.euler_angles = (0.0, 0.0, 0.0)
        # 存储接收到的IMU数据，计算身体速

        average_speed=[0.0 , 0.0 ,0.0]
        if self.lf_mode==1:
            average_speed[:3]+=m.information_lf.toe_velocity_callback
        if self.rf_mode==1:
            average_speed[:3]+=m.information_rf.toe_velocity_callback
        if self.lb_mode==1:
            average_speed[:3]+=m.information_lb.toe_velocity_callback
        if self.rb_mode==1:
            average_speed[:3]+=m.information_rb.toe_velocity_callback
        self.body_velocity=[x/4 for x in average_speed]
        m.imu.Orientation=np.array([msg.orientation.x,msg.orientation.y,msg.orientation.z,msg.orientation.w])
        m.imu.Angular_Velocity=np.array([msg.angular_velocity.x, msg.angular_velocity.y, msg.angular_velocity.z])
        m.imu.Linear_Acceleration=np.array([ msg.linear_acceleration.x, msg.linear_acceleration.y, msg.linear_acceleration.z])
        # self.get_logger().info(f"Orientation: {msg.orientation}")
        # self.get_logger().info(f"Angular Velocity: {msg.angular_velocity}")
        # self.get_logger().info(f"Linear Acceleration: {msg.linear_acceleration}")
        try:
            leg_coords = [
                m.information_lf.toe_position_feedback,
                m.information_rf.toe_position_feedback,
                m.information_lb.toe_position_feedback,
                m.information_rb.toe_position_feedback
            ]
            self.body = self._height_solver_4legs(leg_coords)

            # 计算理论中心
            # theoretical_center = self._calculate_theoretical_center(leg_coords)
            # logger.info(f"Theoretical Body Center: x={theoretical_center[0]:.3f}, y={theoretical_center[1]:.3f}")

        except Exception as e:
            logger.error(f"高度计算错误: {str(e)}")

        self.calculate_foot_information_change(m.information_rb)
        self.calculate_foot_information_change(m.information_lb)
        self.calculate_foot_information_change(m.information_rf)
        self.calculate_foot_information_change(m.information_lf)
        # logger.info("陈浩")
        self.power_lf, self.power_rf, self.power_lb, self.power_rb=mc.plan_legs_power(-self.body[0],-self.body[1],-self.body[2],
                                                                                    self.body_velocity[0],self.body_velocity[1],self.body_velocity[2],
                                                                                    30,1,
                                                                                    [0,0,0.5],[0,0,0],
                                                                                    self.euler_angles[0],self.euler_angles[1],self.euler_angles[2],
                                                                                    m.imu.Angular_Velocity[0],m.imu.Angular_Velocity[1],m.imu.Angular_Velocity[2],
                                                                                    0.01,0.01,
                                                                                    [0,0,0],[0,0,0],[1,1,1,1],
                                                                                    m.leg_lf.q,m.leg_rf.q,m.leg_lb.q,m.leg_rb.q)
        # logger.info(f"机身速度: {self.body_velocity}m")
        # logger.info(f"机身高度: {self.body}m")
        
        # logger.info(f"足虚拟力: { self.power_lf, self.power_rf, self.power_lb, self.power_rb}m")
        # logger.info(f"角度: {  self.euler_angles}")
        # logger.info(self.power_lf, self.power_rf, self.power_lb, self.power_rb)
    def reset_walk_timer(self,time):
        self.each_point_timer_period = time
        self.timer_walk_lb.reset()
        self.timer_walk_rb.reset()
        self.timer_walk_lf.reset()
        self.timer_walk_rf.reset()
    
    def mode_change_callback(self):
        pass
    def timer_walk_callback_rb(self):
        if self.rb_mode==0 and self.rb_end_flag!=1:
            # print("类结好杀ui", self.rb_mode)
            self.rb_end_flag, rbxyz = g.sp_rb.swing_phase_run(self.rb_mode) 
            if self.rb_end_flag==1:
                logger.info("rb_结束了")
            # logger.info("rb_摆动")
            if self.rb_stand_flag1==0:
                g.sp_rb.x_location_start=m.information_rb.toe_position_feedback_raw[0]
                g.sp_rb.y_location_start=m.information_rb.toe_position_feedback_raw[1]
                g.sp_rb.z_location_start=m.information_rb.toe_position_feedback_raw[2]#把触地位置变为初始位置
                self.rb_flag1=1
            self.rb_stand_flag1=1
            self.publish_parameters("rb_para",0.01,4,0,0.01,4,0,0.01,4,0)

            # logger.info(rbxyz)

            if self.is_three_floats_list(rbxyz):
                c0_rb, c1_rb, c2_rb = dog_leg_inverse2.inverse_angle_back(rbxyz[0], rbxyz[1], rbxyz[2], -di.a1, di.l1, di.l2)
                if c0_rb==None or c1_rb==None or c2_rb==None:
                    pass
                else:
                    self.do_angle("rb",[c0_rb, c1_rb, c2_rb],[0.0,0.0,0.0],[0.0,0.0,0.0])
                    m.information_rb.toe_position_feedback_raw[0]=rbxyz[0]
                    m.information_rb.toe_position_feedback_raw[1]=rbxyz[1]
                    m.information_rb.toe_position_feedback_raw[2]=rbxyz[2]

        elif self.rb_mode==1:
            # logger.info("rb_支撑")
            # logger.info(power_lf, power_rf, power_lb, power_rb)
            # logger.info(
            #                 dog_leg_inverse2.angle_to_xyz(m.leg_rf.q[0], m.leg_rf.q[1], m.leg_rf.q[2], -di.a1)
            #                 # dog_leg_inverse2.angle_to_xyz(m.leg_lb.q[0], m.leg_lb.q[1], m.leg_lb.q[2], di.a1),
            #                 )
            if self.rb_stand_flag1==1:
                g.sp_rb_stand.x_location_start=m.information_rb.toe_position_feedback_raw[0]
                g.sp_rb_stand.y_location_start=m.information_rb.toe_position_feedback_raw[1]
                g.sp_rb_stand.z_location_start=m.information_rb.toe_position_feedback_raw[2]#把触地位置变为初始位置
                self.rb_stand_flag1=0
            self.rb_stand_flag1=0
            _, rbxyz = g.sp_rb_stand.swing_phase_run(self.rb_mode) 
            TOR=dog_leg_inverse2.xyz_power_to_tor(self.power_rb[0],self.power_rb[1],self.power_rb[2], m.leg_rb.q[0], m.leg_rb.q[1], m.leg_rb.q[2],-di.a1)
            # logger.info(f"足力矩rb: { TOR}m")
            if self.is_three_floats_list(TOR):
                self.publish_parameters("rb_para",  0.01,  2,  1,  0.01,  2,  1,  0.01,  2,  1)#向其他节电发布参数,每个电机的速度环，位置环，力矩环参数
                # logger.info([-TOR[0],-TOR[1],-TOR[2]])
                if self.is_three_floats_list(rbxyz):
                    c0_rb, c1_rb, c2_rb = dog_leg_inverse2.inverse_angle_back(rbxyz[0], rbxyz[1], rbxyz[2], -di.a1, di.l1, di.l2)
                    if c0_rb==None or c1_rb==None or c2_rb==None:
                        pass
                    else:
                        self.do_angle("rb",[c0_rb, c1_rb, c2_rb],[0.0,0.0,0.0],[TOR[0],TOR[1],TOR[2]])
                        m.information_rb.toe_position_feedback_raw[0]=rbxyz[0]
                        m.information_rb.toe_position_feedback_raw[1]=rbxyz[1]
                        m.information_rb.toe_position_feedback_raw[2]=rbxyz[2]
                        

    def timer_walk_callback_lb(self):
        if self.lb_mode==0 and self.lb_end_flag!=1:
            self.lb_end_flag, lbxyz = g.sp_lb.swing_phase_run(self.lb_mode) 
            if self.lb_end_flag==1:
                logger.info("lb_结束了")
            # logger.info("lb_摆动")
            if self.lb_stand_flag1==0:
                g.sp_lb.x_location_start=m.information_lb.toe_position_feedback_raw[0]
                g.sp_lb.y_location_start=m.information_lb.toe_position_feedback_raw[1]
                g.sp_lb.z_location_start=m.information_lb.toe_position_feedback_raw[2]
                self.lb_stand_flag1=1
            self.lb_stand_flag1=1
            self.publish_parameters("lb_para",0.01,4,0,0.01,4,0,0.01,4,0)

            # logger.info(rbxyz)

            if self.is_three_floats_list(lbxyz):
                c0_lb, c1_lb, c2_lb = dog_leg_inverse2.inverse_angle_back(lbxyz[0], lbxyz[1], lbxyz[2], di.a1, di.l1, di.l2)
                if c0_lb==None or c1_lb==None or c2_lb==None:
                    pass
                else:
                    self.do_angle("lb",[c0_lb, c1_lb, c2_lb],[0.0,0.0,0.0],[0.0,0.0,0.0])
                    m.information_lb.toe_position_feedback_raw[0]=lbxyz[0]
                    m.information_lb.toe_position_feedback_raw[1]=lbxyz[1]
                    m.information_lb.toe_position_feedback_raw[2]=lbxyz[2]

        elif self.lb_mode==1:
            # logger.info("lb_支撑")
            if self.lb_stand_flag1==1:
                g.sp_lb_stand.x_location_start=m.information_lb.toe_position_feedback_raw[0]
                g.sp_lb_stand.y_location_start=m.information_lb.toe_position_feedback_raw[1]
                g.sp_lb_stand.z_location_start=m.information_lb.toe_position_feedback_raw[2]
                self.lb_stand_flag1=0
            self.lb_stand_flag1=0
            _, lbxyz = g.sp_lb_stand.swing_phase_run(self.lb_mode) 
            TOR=dog_leg_inverse2.xyz_power_to_tor(self.power_lb[0],self.power_lb[1],self.power_lb[2], m.leg_lb.q[0], m.leg_lb.q[1], m.leg_lb.q[2],di.a1)
            # logger.info(f"足力矩lb: { TOR}m")
            if self.is_three_floats_list(TOR):
                self.publish_parameters("lb_para",  0.01,  2,  1,  0.01,  2,  1,  0.01,  2,  1)
                if self.is_three_floats_list(lbxyz):
                    c0_lb, c1_lb, c2_lb = dog_leg_inverse2.inverse_angle_back(lbxyz[0], lbxyz[1], lbxyz[2], di.a1, di.l1, di.l2)
                    if c0_lb==None or c1_lb==None or c2_lb==None:
                        pass
                    else:
                        self.do_angle("lb",[c0_lb, c1_lb, c2_lb],[0.0,0.0,0.0],[TOR[0],TOR[1],TOR[2]])
                        m.information_lb.toe_position_feedback_raw[0]=lbxyz[0]
                        m.information_lb.toe_position_feedback_raw[1]=lbxyz[1]
                        m.information_lb.toe_position_feedback_raw[2]=lbxyz[2]


    def timer_walk_callback_rf(self):

        # logger.info(f"cyffff: { self.rf_mode}")
        if self.rf_mode==0 and self.rf_end_flag!=1:
            # logger.info(f"cyffff: { self.rf_mode}m")
            self.rf_end_flag, rfxyz = g.sp_rf.swing_phase_run(self.rf_mode) 
            if self.rf_end_flag==1:
                logger.info("rf_结束了")
            # logger.info("rf_摆动")
            if self.rf_stand_flag1==0:
                g.sp_rf.x_location_start=m.information_rf.toe_position_feedback_raw[0]
                g.sp_rf.y_location_start=m.information_rf.toe_position_feedback_raw[1]
                g.sp_rf.z_location_start=m.information_rf.toe_position_feedback_raw[2]
                self.rf_flag1=1
            self.rf_stand_flag1=1
            self.publish_parameters("rf_para",0.01,4,0,0.01,4,0,0.01,4,0)

            # logger.info(rbxyz)

            if self.is_three_floats_list(rfxyz):
                c0_rf, c1_rf, c2_rf = dog_leg_inverse2.inverse_angle_back(rfxyz[0], rfxyz[1], rfxyz[2], -di.a1, di.l1, di.l2)
                if c0_rf==None or c1_rf==None or c2_rf==None:
                    pass
                else:
                    self.do_angle("rf",[c0_rf, c1_rf, c2_rf],[0.0,0.0,0.0],[0.0,0.0,0.0])
                    m.information_rf.toe_position_feedback_raw[0]=rfxyz[0]
                    m.information_rf.toe_position_feedback_raw[1]=rfxyz[1]
                    m.information_rf.toe_position_feedback_raw[2]=rfxyz[2]
        elif self.rf_mode==1:
            # logger.info("rf_支撑")
            if self.rf_stand_flag1==1:
                g.sp_rf_stand.x_location_start=m.information_rf.toe_position_feedback_raw[0]
                g.sp_rf_stand.y_location_start=m.information_rf.toe_position_feedback_raw[1]
                g.sp_rf_stand.z_location_start=m.information_rf.toe_position_feedback_raw[2]
                self.rf_stand_flag1=0
            self.rf_stand_flag1=0
            _, rfxyz = g.sp_rf_stand.swing_phase_run(self.rf_mode)         
            TOR=dog_leg_inverse2.xyz_power_to_tor(0,0,-1, m.leg_rf.q[0], m.leg_rf.q[1], m.leg_rf.q[2],-di.a1)
            # logger.info(f"足力矩rf: { TOR}m")
            if self.is_three_floats_list(TOR):
                self.publish_parameters("rf_para",  0.01,  2,  1,  0.01,  2,  1,  0.01,  2,  1)
                if self.is_three_floats_list(rfxyz):
                    c0_rf, c1_rf, c2_rf = dog_leg_inverse2.inverse_angle_back(rfxyz[0], rfxyz[1], rfxyz[2], -di.a1, di.l1, di.l2)
                    if c0_rf==None or c1_rf==None or c2_rf==None:
                        pass
                    else:
                        self.do_angle("rf",[c0_rf, c1_rf, c2_rf],[0.0,0.0,0.0],[TOR[0],TOR[1],TOR[2]])
                        m.information_rf.toe_position_feedback_raw[0]=rfxyz[0]
                        m.information_rf.toe_position_feedback_raw[1]=rfxyz[1]
                        m.information_rf.toe_position_feedback_raw[2]=rfxyz[2]


    def timer_walk_callback_lf(self):
        if self.lf_mode==0 and self.lf_end_flag!=1 :
            self.lf_end_flag, lfxyz = g.sp_lf.swing_phase_run(mode = self.lf_mode) 
            # logger.info(self.lf_end_flag)
            if self.lf_end_flag==1:
                logger.info("lf_结束了")
            # logger.info("lf_摆动")
            if self.lf_stand_flag1==0:
                g.sp_lf.x_location_start=m.information_lf.toe_position_feedback_raw[0]
                g.sp_lf.y_location_start=m.information_lf.toe_position_feedback_raw[1]
                g.sp_lf.z_location_start=m.information_lf.toe_position_feedback_raw[2]
                self.lf_stand_flag1=1
            self.lf_stand_flag1=1
            self.publish_parameters("lf_para",0.01,4,0,0.01,4,0,0.01,4,0)

            
            if self.is_three_floats_list(lfxyz):
                c0_lf, c1_lf, c2_lf = dog_leg_inverse2.inverse_angle_back(lfxyz[0], lfxyz[1], lfxyz[2], di.a1, di.l1, di.l2)
                if c0_lf==None or c1_lf==None or c2_lf==None:
                    pass
                else:
                   
                    self.do_angle("lf",[c0_lf, c1_lf, c2_lf],[0.0,0.0,0.0],[0.0,0.0,0.0])
                    m.information_lf.toe_position_feedback_raw[0]=lfxyz[0]
                    m.information_lf.toe_position_feedback_raw[1]=lfxyz[1]
                    m.information_lf.toe_position_feedback_raw[2]=lfxyz[2]
        elif self.lf_mode==1:
            # logger.info("lf_支撑")
            if self.lf_stand_flag1==1:
                g.sp_lf_stand.x_location_start=m.information_lf.toe_position_feedback_raw[0]
                g.sp_lf_stand.y_location_start=m.information_lf.toe_position_feedback_raw[1]
                g.sp_lf_stand.z_location_start=m.information_lf.toe_position_feedback_raw[2]
                self.lf_stand_flag1=0
            self.lf_stand_flag1=0
            _, lfxyz = g.sp_lf_stand.swing_phase_run(mode = self.lf_mode) 
            TOR=dog_leg_inverse2.xyz_power_to_tor(self.power_lf[0],self.power_lf[1],self.power_lf[2], m.leg_lf.q[0], m.leg_lf.q[1], m.leg_lf.q[2],di.a1)
            # logger.info(f"足力矩lf: { TOR}m")
            if self.is_three_floats_list(TOR):
                self.publish_parameters("lf_para",0.01, 2,  1,  0.01,  2,  1,0.01, 2, 1)
                if self.is_three_floats_list(lfxyz):
                    c0_lf, c1_lf, c2_lf = dog_leg_inverse2.inverse_angle_back(lfxyz[0], lfxyz[1], lfxyz[2], di.a1, di.l1, di.l2)
                    if c0_lf==None or c1_lf==None or c2_lf==None:
                        pass
                    else:
                        self.do_angle("lf",[c0_lf, c1_lf, c2_lf],[0.0,0.0,0.0],[TOR[0],TOR[1],TOR[2]])
                        m.information_lf.toe_position_feedback_raw[0]=lfxyz[0]
                        m.information_lf.toe_position_feedback_raw[1]=lfxyz[1]
                        m.information_lf.toe_position_feedback_raw[2]=lfxyz[2]

    def is_three_floats_list(self,variable):
    # 检查是否为列表
        if not isinstance(variable, list):
            return False
        
        # 检查列表长度是否为 3
        if len(variable) != 3:
            return False
        
        # 检查每个元素是否为浮点型
        for element in variable:
            if not isinstance(element, float):
                return False
        
        return True

    def is_all_numbers(self,arr):#判断是不是数字
        return all(isinstance(x, (int, float)) for x in arr)

    def publish_parameters(self,name,kp1,kd1,kt1,kp2,kd2,kt2,kp3,kd3,kt3):#向其他节电发布参数,每个电机的速度环，位置环，力矩环参数
        msg=Float64MultiArray()
        msg.data=[float(kp1), float(kd1), float(kt1), float(kp2), float(kd2), float(kt2), float(kp3), float(kd3), float(kt3)]

        self.my_publishers[name].publish(msg)

    def publish_angles(self, joint_name,msg):#输入名称和角度，调用函数进行发布
        if not self.is_all_numbers(msg.position):
            logger.warning(f"Invalid angle value for {joint_name}: position")
            return  False# 跳过错误数据
        if not self.is_all_numbers(msg.velocity):
            logger.warning(f"Invalid angle value for {joint_name}: velocity")
            return  False# 跳过错误数据
        if not self.is_all_numbers(msg.effort):
            logger.warning(f"Invalid angle value for {joint_name}: effort")
            return  False# 跳过错误数据

        self.my_publishers[joint_name].publish(msg)
        return True
    


    def lfw_callback(self, msg):#收到话题后，调用回调函数，将角度拷贝到这个文件中
        m.leg_lf.q=msg.position
        m.leg_lf.dq=msg.velocity
        m.leg_lf.tau=msg.effort
        m.calculate_foot_information(m.information_lf,msg.position,msg.velocity,msg.effort)
        # logger.info(f"lfq: {m.leg_lf.q}")
        # logger.info(f"lf: {m.information_lf.toe_position_feedback}")
        # logger.info(f"lf: {m.information_lf.toe_position_feedback}")


    def lbw_callback(self, msg):
        m.leg_lb.q=msg.position
        m.leg_lb.dq=msg.velocity
        m.leg_lb.tau=msg.effort
        m.calculate_foot_information(m.information_lb,msg.position,msg.velocity,msg.effort)
        # logger.info(f"lbq: {m.leg_lb.q}")
        # logger.info(f"lb: {m.information_lb.toe_position_feedback}")
        # logger.info(f"lb: {m.information_lb.toe_position_feedback}")
        # logger.info(m.leg_lb.q)
    def rfw_callback(self, msg):
        m.leg_rf.q=msg.position
        m.leg_rf.dq=msg.velocity
        m.leg_rf.tau=msg.effort
        m.calculate_foot_information(m.information_rf,msg.position,msg.velocity,msg.effort)
        # logger.info(f"rfq: {m.leg_rf.q}")
        # logger.info(f"rf: {m.information_rf.toe_position_feedback}")
        # logger.info(m.leg_rf.q)
    def rbw_callback(self, msg):
        m.leg_rb.q=msg.position
        m.leg_rb.dq=msg.velocity
        m.leg_rb.tau=msg.effort
        m.calculate_foot_information(m.information_rb,msg.position,msg.velocity,msg.effort)
        # logger.info(m.leg_rb.q)
        # logger.info(f"rb: {m.information_rb.toe_position_feedback}")
    #输入脚的一串期望路径，angles为二维数组，即足的坐标，times为等待时间
    def do_angle(self,name,angles,v,effort):
        msg = JointState()

        # 初始化 position、velocity 和 effort 列表
        msg.position = angles
        msg.velocity = v
        msg.effort = effort

        self.publish_angles(name, msg)




    def _quat_to_euler(self, q):
        """手动实现四元数到欧拉角转换 (ZYX顺序)"""
        x, y, z, w = q
        # 计算偏航角 (yaw)
        siny_cosp = 2 * (w * z + x * y)
        cosy_cosp = 1 - 2 * (y**2 + z**2)
        yaw =0 #np.arctan2(siny_cosp, cosy_cosp)
        
        # 计算俯仰角 (pitch)
        sinp = 2 * (w * y - z * x)
        if abs(sinp) >= 1:
            pitch = np.sign(sinp) * np.pi / 2  # 处理90度奇点
        else:
            pitch = np.arcsin(sinp)
        
        # 计算横滚角 (roll)
        sinr_cosp = 2 * (w * x + y * z)
        cosr_cosp = 1 - 2 * (x**2 + y**2)
        roll = np.arctan2(sinr_cosp, cosr_cosp)

        return (roll, pitch, yaw)  # 返回顺序为(roll, pitch, yaw)



    def _calculate_theoretical_center(self, leg_coords):
        """计算四条腿足末端的理论中心坐标（x,y平均值）"""
        sum_x = 0.0
        sum_y = 0.0
       
        for coord in leg_coords:
            if len(coord) < 2:
                raise ValueError("坐标维度不足")
            sum_x += coord[0]
            sum_y += coord[1]
       
        center_x = sum_x / 4
        center_y = sum_y / 4
        return (center_x, center_y)



    def _height_solver_4legs(self, leg_coords):
        """使用手动计算的欧拉角进行高度计算"""
        roll, pitch, yaw = self.euler_angles
        # logger.info(f"roll{roll}")
        # logger.info(f"pitch{pitch}")
        # logger.info(f"yaw{yaw}")
        # 构建旋转矩阵（ZYX顺序）
        Rz = np.array([
            [np.cos(yaw), -np.sin(yaw), 0],
            [np.sin(yaw), np.cos(yaw), 0],
            [0, 0, 1]
        ])
        Ry = np.array([
            [np.cos(pitch), 0, np.sin(pitch)],
            [0, 1, 0],
            [-np.sin(pitch), 0, np.cos(pitch)]
        ])
        Rx = np.array([
            [1, 0, 0],
            [0, np.cos(roll), -np.sin(roll)],
            [0, np.sin(roll), np.cos(roll)]
        ])
        R = Rz @ Ry @ Rx
        # logger.info(f"Rcyf{R}")
        # R_z = R[2, :]  # 提取Z轴分量

        # # 构建最小二乘方程组
        # A = np.ones((4, 1))
        # b = []
        # for coord in leg_coords:
        #     if len(coord) != 3:
        #         raise ValueError("腿部坐标维度错误")
        #     x, y, z = coord
        #     b.append(-(R_z[0]*x + R_z[1]*y + R_z[2]*z))
        
        # return np.linalg.lstsq(A, np.array(b), rcond=None)[0][0]

        # R_x, R_y, R_z = R[0, :], R[1, :], R[2, :] # 提取 X、Y、Z 轴分量 # 构建最小二乘方程组 
        # A = np.ones((4, 3)) # 4 行，3 列，分别对应 x、y、z 
        # b = [] 
        # for coord in leg_coords: 
        #     if len(coord) != 3: 
        #         raise ValueError("腿部坐标维度错误") 
        #     x, y, z = coord # 构造 b 的每一行 
        #     b.append([ -(R_x[0] * x + R_x[1] * y + R_x[2] * z), # x 方向 
        #           -(R_y[0] * x + R_y[1] * y + R_y[2] * z), # y 方向 
        #           -(R_z[0] * x + R_z[1] * y + R_z[2] * z) # z 方向 
        #     ]) # 转换为 NumPy 矩阵 
        # b = np.array(b) 
        # # 求解最小二乘问题 
        # offsets, _, _, _ = np.linalg.lstsq(A, b, rcond=None) 
        # # offsets 包含 x, y, z 偏移量 
        # return offsets 
        column_matrices = [np.array(coord).reshape(-1, 1) for coord in leg_coords] # 使用旋转矩阵变换腿坐标 
        # logger.info(f"column_matrices{column_matrices}")
        results = [R @ column_matrix for column_matrix in column_matrices] # 计算几何中心在世界坐标系中的坐标 
        # logger.info(f" results{results}")
        back = [np.mean([res[i, 0] for res in results]) for i in range(3)] 
        # logger.info(f" backcyf{back}")
        return back

        

    
    def update_all_angle(self,msg_lf,msg_rf,msg_lb,msg_rb):#一下发布所有角度
            self.publish_angles("lf",msg_lf)
            self.publish_angles("rf",msg_rf)
            self.publish_angles("lb",msg_lb)
            self.publish_angles("rb",msg_rb)

    #新定义的函数用来判断速度是否突变
    def calculate_foot_information_change(self,foot_calculate_information_here):
        if foot_calculate_information_here.name == "rb":  # 检测这是哪条腿
            
            # 检测速度突变
            speed_change_exceeded_threshold = False
            if foot_calculate_information_here.toe_power[2] - foot_calculate_information_here.prev_toe_power[2] > FORCE_THRESHOLD:
                speed_change_exceeded_threshold = True
                logger.info(f"Foot {foot_calculate_information_here.name} touched the ground on axis {2}")
                # self.rb_stand_flag=1
                
                logger.info(f"Foot {foot_calculate_information_here.name} change the mode")
                #logger.info(f"Foot {foot_calculate_information_here.name} have power:{foot_calculate_information_here.toe_power}.")
                #rclpy.shutdown()   #仅用于测试能否正常检测并停止摆动 

            if not speed_change_exceeded_threshold:
                
                # logger.info(f"Foot {foot_calculate_information_here.name} did not touch the ground.")
                pass
                
                
            foot_calculate_information_here.prev_toe_power= foot_calculate_information_here.toe_power

        elif foot_calculate_information_here.name == "lf":
            
            # 检测速度突变
            speed_change_exceeded_threshold = False
            if foot_calculate_information_here.toe_power[2] - foot_calculate_information_here.prev_toe_power[2] > FORCE_THRESHOLD:
                speed_change_exceeded_threshold = True
                logger.info(f"Foot {foot_calculate_information_here.name} touched the ground on axis {2}")
                # self.lf_stand_flag=1
                logger.info(f"Foot {foot_calculate_information_here.name} change the mode")

            if not speed_change_exceeded_threshold:
                # logger.info(f"Foot {foot_calculate_information_here.name} did not touch the ground.")
                # logger.info(f"Foot {foot_calculate_information_here.name} have power:{foot_calculate_information_here.toe_power}.")
                
                pass
            foot_calculate_information_here.prev_toe_power= foot_calculate_information_here.toe_power
        # logger.info(f"Foot {foot_calculate_information_here.name} have power:{foot_calculate_information_here.toe_power}.")

        elif foot_calculate_information_here.name == "rf":
            
            # 检测速度突变
            speed_change_exceeded_threshold = False
            if foot_calculate_information_here.toe_power[2] - foot_calculate_information_here.prev_toe_power[2] > FORCE_THRESHOLD:
                speed_change_exceeded_threshold = True
                logger.info(f"Foot {foot_calculate_information_here.name} touched the ground on axis {2}")
                # self.rf_stand_flag=1
                logger.info(f"Foot {foot_calculate_information_here.name} have power:{foot_calculate_information_here.toe_power}.")
                rclpy.shutdown()   #仅用于测试能否正常检测并停止摆动 
            
            if not speed_change_exceeded_threshold:
                # logger.info(f"Foot {foot_calculate_information_here.name} did not touch the ground.")
                # logger.info(f"Foot {foot_calculate_information_here.name} have power:{foot_calculate_information_here.toe_power}.")
                
                pass
            
            foot_calculate_information_here.prev_toe_power= foot_calculate_information_here.toe_power
        
        elif foot_calculate_information_here.name == "lb":
            
            # 检测速度突变
            speed_change_exceeded_threshold = False
            if foot_calculate_information_here.toe_power[2] - foot_calculate_information_here.prev_toe_power[2] > FORCE_THRESHOLD:
                speed_change_exceeded_threshold = True
                logger.info(f"Foot {foot_calculate_information_here.name} touched the ground on axis {2}")
                # self.lb_stand_flag=1
                #logger.info(f"Foot {foot_calculate_information_here.name} have power:{foot_calculate_information_here.toe_power}.")
            # rclpy.shutdown()   #仅用于测试能否正常检测并停止摆动 

            if not speed_change_exceeded_threshold:
                # logger.info(f"Foot {foot_calculate_information_here.name} did not touch the ground.")
                # logger.info(f"Foot {foot_calculate_information_here.name} have power:{foot_calculate_information_here.toe_power}.")
                
                pass
            foot_calculate_information_here.prev_toe_power= foot_calculate_information_here.toe_power


# 写入文件

###############################################################################################这些函数是我自己写的逻辑，不用这个规划轨迹了，在规划完点之后解算出角度调用publish_angle发布就可以了
# 修改为嵌套字典
def generate_data(f_lf, s_lf, t_lf, f_rf, s_rf, t_rf, f_lb, s_lb, t_lb, f_rb, s_rb, t_rb):
    return {
        'lf': {'f': f_lf, 's': s_lf, 't': t_lf},
        'rf': {'f': f_rf, 's': s_rf, 't': t_rf},
        'lb': {'f': f_lb, 's': s_lb, 't': t_lb},
        'rb': {'f': f_rb, 's': s_rb, 't': t_rb}
    }

# 修改数据
def modify_data(existing_data, modifications):
    # 创建数据副本，避免直接修改全局数据
    updated_data = existing_data.copy()
    for wheel, mods in modifications.items():
        updated_data[wheel].update(mods)  # 更新嵌套字典中的数据
    return updated_data

def get_angles(points):
    angles=[]
    min_length = min(len(point) for point in points)

    for i in range(0,min_length):
        modifications = {}
        c0_lf, c1_lf, c2_lf = dog_leg_inverse2.inverse_angle_back(points[0][i][0], points[0][i][1], points[0][i][2], di.a1, di.l1, di.l2)
        if c0_lf==None or c1_lf==None or c2_lf==None:
            continue
        # modifications1 = {'lf': {'f': c0, 's': c1, 't': c2}}
        c0_rf, c1_rf, c2_rf = dog_leg_inverse2.inverse_angle_back(points[1][i][0], points[1][i][1], points[1][i][2], -di.a1, di.l1, di.l2)
        if c0_rf==None or c1_rf==None or c2_rf==None:
            continue        
        # modifications2 = {'rf': {'f': c3, 's': c4, 't': c5}}
        c0_lb, c1_lb, c2_lb = dog_leg_inverse2.inverse_angle_back(points[2][i][0], points[2][i][1], points[2][i][2], di.a1, di.l1, di.l2)
        if c0_lb==None or c1_lb==None or c2_lb==None:
            continue
        # modifications3 = {'lb': {'f': c0, 's': c1, 't': c2}}
        c0_rb, c1_rb, c2_rb = dog_leg_inverse2.inverse_angle_back(points[3][i][0], points[3][i][1], points[3][i][2], -di.a1, di.l1, di.l2)
        if c0_rb==None or c1_rb==None or c2_rb==None:
            continue
        # modifications4 = {'rb': {'f': c3, 's': c4, 't': c5}}
        
        data1=generate_data(c0_lf, c1_lf, c2_lf,c0_rf, c1_rf, c2_rf,c0_lb, c1_lb, c2_lb,c0_rb, c1_rb, c2_rb)

        angles.append(data1)
        # write_to_file(data)
    return angles


# 主函数
def main(args=None):
    logger.info("000")
    global data

    rclpy.init()
    node = DogLegControlNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()
    logger.info("000")

    logger.info("Initial data written to file")

    #输入足末端点
    interpolated_points_lf = dog_leg_inverse2.interpolate_points_3d((0,0,-0.20 ),(0,0,-0.200), 0.005)
    interpolated_points_rb = dog_leg_inverse2.interpolate_points_3d((0,0,-0.20 ),(0,0,-0.20), 0.005)
    interpolated_points_rf = dog_leg_inverse2.interpolate_points_3d((0,0,-0.20 ),(0,0,-0.20), 0.005)
    interpolated_points_lb = dog_leg_inverse2.interpolate_points_3d((0,0,-0.20 ),(0,0,-0.20), 0.005)
    #

    while True:
        # logger.info(m.information_rb.toe_power)
        # logger.info(m.information_rb_walk.toe_velocity_callback)
        # logger.info(m.information_rb_walk.toe_power)
        # move_straight_line((0, 0.6, 0.25), (0.0, 0.7, 0), 0.005, "lb",1)
        # 根据需要，可以继续添加其他轮子的数据修改函数
        pass





if __name__ == '__main__':
    main()
