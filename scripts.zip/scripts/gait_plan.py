# 变量说明
# 1. 步态周期：step_period
# 2. 支撑相占空比：n
# 3. kx,ky: 步态参数(后期根据步态优化得到)
# 4. x_speed_now, y_speed_now: 机器狗当前速度
# 5. x_speed_exp, y_speed_exp: 机器狗期望速度
# 6. x_location_start, y_location_start, z_location_start: 狗腿末端初始位置
# 7. x_location_final, y_location_final, z_location_final: 狗腿末端期望位置
# 8. h: 跨腿高度
# 9. x, y, z: 规划摆线轨迹的x,y,z坐标

import math
import time
import rclpy
from rclpy.node import Node
import logging
import time
import json
import os
from . import dog_leg_inverse2
from . import dog_imformation as di
from . import motor as m
from std_msgs.msg import Float64
from sensor_msgs.msg import JointState
from std_msgs.msg import Float64MultiArray
from . import gait_plan as g
from sensor_msgs.msg import Imu
import numpy as np
from . import motion_control as mc

# 配置 logger
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class swing_phase:
    def __init__(self,tph,nh,kxh,kyh,xsnh,ysnh,xseh,yseh,xls,yls,zls,h,minmax):
        self.i=0
        self.step_period = tph#每次踏步的周期
        self.n = nh#
        self.kx = kxh
        self.ky = kyh
        self.x_speed_now =xsnh
        self.y_speed_now =ysnh
        self.x_speed_exp = xseh
        self.y_speed_exp = yseh
        self.x_location_start = xls
        self.y_location_start = yls
        self.z_location_start = zls
        self.h = h
        self.t_period_now=0
        self.t_period_start=0
        self.x_max=minmax[0]
        self.x_min=minmax[1]
        self.y_max=minmax[2]
        self.y_min=minmax[3]
        self.z_max=minmax[4]
        self.z_min=minmax[5]

    def swing_phase_run(self, mode):
        
        if self.i==0:
            self.t_period_start = time.time()  # 记录当前迈腿周期开始时间
            self.i+=1
        self.t_period_now = time.time()     # 记录该周期内此次循环的时间
        t =self.t_period_now - self.t_period_start      
        if t >= self.n*self.step_period:           # 若该周期内的时间超过了一个步态周期，则进入等待
            # time.sleep((1-self.n)*self.step_period)     # 当前步态周期的摆动动作完成，该条腿变为支撑相，等待下一个步态周期的摆动相到来

            # print(33333333)
            self.i=0
            return 1, None
        
        x_location_final = 0.5*self.x_speed_now*self.n*self.step_period-self.kx*(self.x_speed_exp-self.x_speed_now) + self.x_location_start    # 计算狗腿末端期望位置-
        y_location_final = 0.5*self.y_speed_now*self.n*self.step_period-self.ky*(self.y_speed_exp-self.y_speed_now) + self.y_location_start
        logger.info(x_location_final)
        logger.info(y_location_final)
        

        a = (2*math.pi*t)/(self.n*self.step_period)     

        x = (x_location_final-self.x_location_start)*(a-math.sin(a))/(2*math.pi) + self.x_location_start    # 计算摆线轨迹的x,y,z坐标
        y = (y_location_final-self.y_location_start)*(a-math.sin(a))/(2*math.pi) + self.y_location_start
        z = self.z_location_start+self.h*(1-math.cos(a))/2

        return 0, [x,y,z]

#                (self,tph,nh,kxh,kyh,xsnh,ysnh,xseh,yseh,xls,yls,zls,h,minmax)
sp_rb=swing_phase(2,0.5,0.1,0.1,0,0,-1.0,0,0.01,-0.05,-0.3,0.15,[0.2,-0.2,0.1,-0.1,-0.05,-0.4])
sp_lb=swing_phase(2,0.5,0.1,0.1,0,0,-1.0,0,0.01,0.05,-0.3,0.15,[0.2,-0.2,0.1,-0.1,-0.05,-0.4])
sp_rf=swing_phase(2,0.5,0.1,0.1,0,0,-1.0,0,0.01,-0.05,-0.3,0.15,[0.2,-0.2,0.1,-0.1,-0.05,-0.4])
sp_lf=swing_phase(2,0.5,0.1,0.1,0,0,-1.0,0,0.01,0.05,-0.3,0.15,[0.2,-0.2,0.1,-0.1,-0.05,-0.4])
sp_rb_stand=swing_phase(2,0.5,0.1,0.1,0,0,1.0,0,0.01,-0.05,-0.3,0,[0.2,-0.2,0.1,-0.1,-0.05,-0.4])
sp_lb_stand=swing_phase(2,0.5,0.1,0.1,0,0,1.0,0,0.01,0.05,-0.3,0,[0.2,-0.2,0.1,-0.1,-0.05,-0.4])
sp_rf_stand=swing_phase(2,0.5,0.1,0.1,0,0,1.0,0,0.01,-0.05,-0.3,0,[0.2,-0.2,0.1,-0.1,-0.05,-0.4])
sp_lf_stand=swing_phase(2,0.5,0.1,0.1,0,0,1.0,0,0.01,0.05,-0.3,0,[0.2,-0.2,0.1,-0.1,-0.05,-0.4])