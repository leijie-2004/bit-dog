#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from sensor_msgs.msg import Imu
import numpy as np
import threading
import time
import sys
import json
sys.path.append('../lib')
from . import dog_leg_inverse2
from . import motor as m
import logging
import time
from . import dog_imformation as di
from sensor_msgs.msg import JointState
sys.path.append('/home/rm/download/fish_ws_gou8/fish_ws/fishbot_description/fishbot_description/lib')
from unitree_actuator_sdk import *



# 配置 logger
logging.basicConfig(level=logging.INFO)#配置和可以在终端输出文字
logger = logging.getLogger(__name__)




def read_from_file():#没用了
    try:
        with open('shared_data.txt', 'r') as f:
            return json.load(f)
    except (json.JSONDecodeError, FileNotFoundError) as e:
        logger.error(f"Error reading from file: {e}")
        return None
    

class RotateWheelNode(Node):#发布虚拟文件关节角度的节点
    def __init__(self, name):
        super().__init__(name)#订阅话题，话题在/robot工作空间，节点在/工作空间
        topic_prefix= "robot/"
        self.my_subscriptions = {
            'lf': self.create_subscription(JointState, topic_prefix +'lf', self.lf_callback, 30),
            'rf': self.create_subscription(JointState, topic_prefix +'rf', self.rf_callback, 30),
            'lb': self.create_subscription(JointState, topic_prefix +'lb', self.lb_callback, 30),
            'rb': self.create_subscription(JointState, topic_prefix +'rb', self.rb_callback, 30),

        }
        self.my_publishers = {
            'lf_feedback': self.create_publisher(JointState, topic_prefix+'lf_feedback', 30),
            'rf_feedback': self.create_publisher(JointState, topic_prefix+'rf_feedback', 30),
            'lb_feedback': self.create_publisher(JointState, topic_prefix+'lb_feedback', 30),
            'rb_feedback': self.create_publisher(JointState, topic_prefix+'rb_feedback', 30),

        }
        self.subscription = self.create_subscription(
            Imu,
            '/imu',
            self.imu_callback,
            10  # 队列大小
        )
        self.msg_lf_feedback = JointState()
        self.msg_rf_feedback = JointState()
        self.msg_lb_feedback = JointState()
        self.msg_rb_feedback = JointState()
        self.msg_rb_feedback.name=['rb_joint1', 'rb_joint2', 'rb_joint3']
        self.msg_rb_feedback.position = [0.0,0.0,0.0]
        self.msg_rb_feedback.velocity = [0.0,0.0,0.0]
        self.msg_rb_feedback.effort = [0.0,0.0,0.0]
        self.get_logger().info(f"node {name} init..")
        self._init_joint_states()
        self.pub_rate = self.create_rate(30)
        self.thread_ = threading.Thread(target=self._thread_pub)
        self.thread_.start()
        self.timer = self.create_timer(0.006, self.timer_callback)#下面的timer的回调频率控制函数
        self.timer_calculate=self.create_timer(0.02, self.timer_calculate_callback)#下面的timer的回调频率控制函数
        self.ti=0
        self.tj=0
        self.tk=0

    def is_three_floats_list(self,variable):
    # 检查是否为列表
        if not isinstance(variable, list):
            return False
        
        # 检查列表长度是否为 3
        if len(variable) != 3:
            return False
        
        # 检查每个元素是否为浮点型
        for element in variable:
            if not isinstance(element, float):
                return False
        
        return True
    


    def is_all_numbers(self,arr):
        return all(isinstance(x, (int, float)) for x in arr)

    def publish_feedback_information(self, joint_name,msg):#输入名称和角度，调用函数进行发布
        if not self.is_all_numbers(msg.position):
            logger.warning(f"Invalid angle value for {joint_name}: position")
            return  False# 跳过错误数据
        if not self.is_all_numbers(msg.velocity):
            logger.warning(f"Invalid angle value for {joint_name}: velocity")
            return  False# 跳过错误数据
        if not self.is_all_numbers(msg.effort):
            logger.warning(f"Invalid angle value for {joint_name}: effort")
            return  False# 跳过错误数据
   
        self.my_publishers[joint_name].publish(msg)
        return True

    def motor_slope(self,legh,max,min):
                if legh.q[0]-legh.q_last[0]>max:
                    legh.q[0]=legh.q_last[0]+max
                elif legh.q[0]-legh.q_last[0]<min:
                    legh.q[0]=legh.q_last[0]+min
                if legh.q[1]-legh.q_last[1]>max:
                    legh.q[1]=legh.q_last[1]+max
                elif legh.q[1]-legh.q_last[1]<min:
                    legh.q[1]=legh.q_last[1]+min
                if legh.q[2]-legh.q_last[2]>max:
                    legh.q[2]=legh.q_last[2]+max
                elif legh.q[2]-legh.q_last[2]<min:
                    legh.q[2]=legh.q_last[2]+min      

    def timer_callback(self):#定时器回调函数，电机控制函数位置
                # # logger.info(m.motor_rb_ex.q)
                self.motor_slope(m.leg_rb,0.01,-0.01)
                if m.move_motor(m.leg_rb,0, m.motor_rb_ex.q[0],0,0,0.008,3,3.14/2,-3.14/2):#move_motor(legh, id, q, dq, tau, kp, kd,q_max,q_min)
                    # logger.info(self.ti-time.time())
                    self.ti=time.time()
                    
                if m.move_motor(m.leg_rb,1, m.motor_rb_ex.q[1],0,0,0.01,2,3.14/2,-3.14/2):
                    # logger.info(self.tj-time.time())
                    self.tj=time.time()
                    
                if m.move_motor(m.leg_rb,2, m.motor_rb_ex.q[2],0,0,0.01,2,0,3.14):
                    # logger.info(self.tk-time.time())
                    self.tk=time.time()

                # m.move_motor(m.leg_rb,1, 0,0,0,0.005,1)#move_motor(legh, id, q, dq, tau, kp, kd)
          
                # m.move_motor(m.leg_rb,1, -3.14/2,0,0,0.005,1)
        
                # m.move_motor(m.leg_rb,2, 3.14/2,0,0,0.01,1)
    
    def timer_calculate_callback(self):#定时器回调函数，电机控制函数位置

        self.msg_rb_feedback.position= np.array(m.leg_rb.q, dtype=float).tolist()
        # logger.info(np.array(m.leg_rb.q, dtype=float))
        self.msg_rb_feedback.velocity=np.array(m.leg_rb.dq, dtype=float).tolist()
        self.msg_rb_feedback.effort=np.array(m.leg_rb.tau, dtype=float).tolist()
        # logger.info(self.msg_rb_feedback)
        self.publish_feedback_information("rb_feedback", self.msg_rb_feedback)


    def _init_joint_states(self):#初始化
        self.i=0
        self.joint_positions = [0.0] * 12  # 确保初始值匹配关节数量


    def _thread_pub(self):#建立进程的函数
        while rclpy.ok():
            self.pub_rate.sleep()


#从ROS2的订阅者得到信息并放到我们的变量中，在文件中可以调用
    def lf_callback(self, msg):#收到话题后，调用回调函数，将角度拷贝到这个文件中
        m.motor_lf_ex.q=msg.position
        m.motor_lf_ex.dq=msg.velocity
        m.motor_lf_ex.tau=msg.effort

    def lb_callback(self, msg):
        m.motor_lb_ex.q=msg.position
        m.motor_lb_ex.dq=msg.velocity
        m.motor_lb_ex.tau=msg.effort      

    def rf_callback(self, msg):
        m.motor_rf_ex.q=msg.position
        m.motor_rf_ex.dq=msg.velocity
        m.motor_rf_ex.tau=msg.effort
        
    def rb_callback(self, msg):
        m.motor_rb_ex.q=msg.position
        m.motor_rb_ex.dq=msg.velocity
        m.motor_rb_ex.tau=msg.effort
       


#从ROS2的订阅者得到信息并放到我们的变量中，在文件中可以调用

#imu
    def imu_callback(self, msg):
        # 打印接收到的IMU数据
        # self.get_logger().info(f"Received IMU data:")
        # self.get_logger().info(f"Orientation: {msg.orientation}")
        # self.get_logger().info(f"Angular Velocity: {msg.angular_velocity}")
        # self.get_logger().info(f"Linear Acceleration: {msg.linear_acceleration}")
        pass
#imu



def main(args=None):
    rclpy.init(args=args)
    node = RotateWheelNode("rotate_fishbot_wheel")
    global angles
    def update_joint_positions(node):
        while rclpy.ok():
          
            # logger.info("data read from files")

            # time.sleep(0.001)
            #正运动学结算

            # logger.info(m.motor_rb_ex.q)
            # logger.info(m.information_rb.toe_power)
            # logger.info(m.information_rb.toe_position_feedback)
            # logger.info(m.information_rb.toe_velocity_callback)

            # logger.info(m.leg_rb.q)

            pass
           
    
    update_thread = threading.Thread(target=update_joint_positions, args=(node,))
    update_thread.start()

    rclpy.spin(node)
    rclpy.shutdown()


if __name__ == '__main__':
    main()
